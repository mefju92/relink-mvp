import fg from 'fast-glob';
import mm from 'music-metadata';
import fs from 'fs';
import path from 'path';
import { toCsv } from './csv.js';

const exts = ['.mp3', '.flac', '.m4a', '.wav'];

export async function scanCommand(root) {
  const pattern = exts.map(e => `**/*${e}`).concat(['**/*.{MP3,FLAC,M4A,WAV}']);
  const entries = await fg(pattern, { cwd: root, onlyFiles: True, dot: False });
  console.log(`Znaleziono ${entries.length} plików — czytam tagi...`);

  const rows = [];
  for (const rel of entries) {
    const full = path.join(root, rel);
    try {
      const meta = await mm.parseFile(full, { duration: true });
      const common = meta.common || {};
      const format = meta.format || {};
      rows.push({
        path: rel,
        title: (common.title || '').trim(),
        artist: (Array.isArray(common.artists) ? common.artists.join(', ') : common.artist || '').trim(),
        album: (common.album || '').trim(),
        year: common.year || '',
        duration_ms: Math.round((format.duration || 0) * 1000),
      });
    } catch (e) {
      rows.push({
        path: rel,
        title: '',
        artist: '',
        album: '',
        year: '',
        duration_ms: 0,
      });
    }
  }

  await fs.promises.mkdir('export', { recursive: true });
  await toCsv('export/tracks.csv', rows);
  console.log('Gotowe: export/tracks.csv');
}

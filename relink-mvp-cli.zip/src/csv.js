import fs from 'fs';

export async function toCsv(outPath, rows) {
  if (!rows.length) {
    await fs.promises.writeFile(outPath, '');
    return;
  }
  const headers = Object.keys(rows[0]);
  const lines = [headers.join(',')];
  for (const r of rows) {
    const line = headers.map(h => escapeCsv(r[h] ?? '')).join(',');
    lines.push(line);
  }
  await fs.promises.writeFile(outPath, lines.join('\n'), 'utf8');
}

function escapeCsv(val) {
  const s = String(val);
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

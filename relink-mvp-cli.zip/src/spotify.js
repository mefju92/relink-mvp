// Szkielet — dokończymy po skanie CSV
// Docelowo: auth (OAuth), search, create playlist
import SpotifyWebApi from 'spotify-web-api-node';
import fs from 'fs';

export async function matchCommand() {
  console.log('TODO: implement match (czytamy export/tracks.csv, szukamy w Spotify)');
  // 1) wczytaj tracks.csv
  // 2) dla każdego wiersza złoż zapytanie: `${title} ${artist}`
  // 3) przelicz score na bazie tytuł/artist/duration
  // 4) zapisz export/matches.csv
}

export async function playlistCommand() {
  console.log('TODO: implement playlist (czytamy export/matches.csv i tworzymy playlistę)');
  // 1) OAuth → token
  // 2) createPlaylist(name) → addTracks
}
